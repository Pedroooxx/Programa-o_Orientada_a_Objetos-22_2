//Nome: Pedro de Oliveira Machado -  RA: 2417855

/*a.1)_Acrescente mais uma linha de exibição no programa anterior.*/

public class Exa_1 {
    public static void main(String arg[]){
    
        System.out.println("Facim, facim!!!");
        System.out.println("Facim, facim de novo!!!");

    }
}
    